/**
 * Utilities for the computation of preconditions.
 */
package org.sosy_lab.cpachecker.util.precondition;