/**
 * Pattern matching for Formula ASTs.
 */
package org.sosy_lab.cpachecker.util.predicates.matching;