/**
 * Inference rules for computing predicates that
 * include arrays and quantifiers.
 */
package org.sosy_lab.cpachecker.util.precondition.segkro.rules;