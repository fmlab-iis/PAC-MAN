/**
 * Tests for the inference rules.
 */
package org.sosy_lab.cpachecker.util.precondition.segkro.rules.tests;