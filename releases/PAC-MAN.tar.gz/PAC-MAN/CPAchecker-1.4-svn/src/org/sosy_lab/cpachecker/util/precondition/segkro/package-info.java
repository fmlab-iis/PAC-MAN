/**
 * Precondition inference using the approach presented
 * by Seghir and Kroening, 2013.
 */
package org.sosy_lab.cpachecker.util.precondition.segkro;