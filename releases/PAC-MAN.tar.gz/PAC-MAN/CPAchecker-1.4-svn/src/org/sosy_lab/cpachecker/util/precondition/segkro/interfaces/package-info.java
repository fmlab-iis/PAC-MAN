/**
 * 
 */
package org.sosy_lab.cpachecker.util.precondition.segkro.interfaces;